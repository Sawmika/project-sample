<!-- Include FontAwesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

<div class="sidebar-menu" id="sidebarMenu">
    <div class="sidebar-header">
        <div class="logo">
            <a href="dashboard.php">
                <img src="http://localhost/zms/images/zoolg.png" alt="Logo" class="logo-img">
            </a>
            <a href="dashboard.php" class="admin-text">ADMIN</a>
        </div>
        <button class="menu-toggle" id="menuToggle">&#9776;</button>
    </div>
    
    <div class="main-menu">
        <div class="menu-inner">
            <nav>
                <ul class="metismenu" id="menu">
                    <li class="active">
                        <a href="dashboard.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
                    </li>
                    <li class="has-arrow">
                        <a href="#"><i class="fas fa-paw"></i><span>Animals</span></a>
                        <ul class="collapse">
                            <li><a href="add-animals.php"><i class="fas fa-plus-circle"></i><span>Add Animals</span></a></li>
                            <li><a href="manage-animals.php"><i class="fas fa-edit"></i><span>Manage Animals</span></a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="manage-ticket.php"><i class="fas fa-ticket-alt"></i><span>Manage Tickets</span></a>
                    </li>
                    <li class="has-arrow">
                        <a href="#"><i class="fas fa-tags"></i><span>Normal Ticket</span></a>
                        <ul class="collapse">
                            <li><a href="add-normal-ticket.php"><i class="fas fa-plus-circle"></i><span>Add Ticket</span></a></li>
                            <li><a href="manage-normal-ticket.php"><i class="fas fa-edit"></i><span>Manage Ticket</span></a></li>
                        </ul>
                    </li>
                    <li class="has-arrow">
                        <a href="#"><i class="fas fa-globe"></i><span>Foreigners Ticket</span></a>
                        <ul class="collapse">
                            <li><a href="add-foreigners-ticket.php"><i class="fas fa-plus-circle"></i><span>Add Ticket</span></a></li>
                            <li><a href="manage-foreigners-ticket.php"><i class="fas fa-edit"></i><span>Manage Ticket</span></a></li>
                        </ul>
                    </li>
                    <li class="has-arrow">
                        <a href="#"><i class="fas fa-info-circle"></i><span>Pages</span></a>
                        <ul class="collapse">
                            <li><a href="aboutus.php"><i class="fas fa-address-card"></i><span>About Us</span></a></li>
                            <li><a href="contactus.php"><i class="fas fa-envelope"></i><span>Contact Us</span></a></li>
                        </ul>
                    </li>
                    <li class="has-arrow">
                        <a href="#"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
                        <ul class="collapse">
                            <li><a href="between-dates-normalreports.php"><i class="fas fa-file-alt"></i><span>Normal Report</span></a></li>
                            <li><a href="between-dates-foreignerreports.php"><i class="fas fa-file-alt"></i><span>Foreigner Report</span></a></li>
                        </ul>
                    </li>
                    <li class="has-arrow">
                        <a href="#"><i class="fas fa-search"></i><span>Search</span></a>
                        <ul class="collapse">
                            <li><a href="normal-search.php"><i class="fas fa-search"></i><span>Normal Ticket Search</span></a></li>
                            <li><a href="foreigner-search.php"><i class="fas fa-search"></i><span>Foreigner Ticket Search</span></a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>

<style>
    .sidebar-menu {
        background: #1E1E2D;
        width: 200px;
        height: 100vh;
        position: fixed;
        top: 0;
        left: 0;
        color: white;
        transition: all 0.3s ease-in-out;
        overflow-y: auto;
    }
    .sidebar-header {
        padding: 20px;
        text-align: center;
        border-bottom: 1px solid rgba(255,255,255,0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .menu-toggle {
        background: none;
        border: none;
        color: white;
        font-size: 24px;
        cursor: pointer;
        display: none;
    }
    .menu-inner {
        padding: 20px 0;
    }
    .metismenu li a {
        color: white;
        display: flex;
        align-items: center;
        padding: 12px 20px;
        font-size: 15px;
        transition: all 0.3s;
        cursor: pointer;
    }
    .metismenu li a i {
        margin-right: 10px;
    }
    .metismenu li a:hover {
        background: #282842;
        border-left: 4px solid #4CAF50;
    }
    /* Remove the right arrow after .has-arrow items */
    .metismenu .has-arrow:after {
        content: none;
    }
    .metismenu .collapse {
        display: none;
    }
    .metismenu li.active a {
        background: #4CAF50;
    }
    @media (max-width: 768px) {
        .sidebar-menu {
            width: 0;
            overflow: hidden;
        }
        .menu-toggle {
            display: block;
        }
        .sidebar-menu.open {
            width: 250px;
        }
    }
</style>

<script>
    document.querySelectorAll('.has-arrow').forEach(item => {
        item.addEventListener('click', event => {
            let submenu = item.nextElementSibling;
            if (submenu.classList.contains('collapse')) {
                submenu.classList.toggle('open');
                item.classList.toggle('open');
            }
        });
    });

    document.getElementById('menuToggle').addEventListener('click', function() {
        document.getElementById('sidebarMenu').classList.toggle('open');
    });
</script>
