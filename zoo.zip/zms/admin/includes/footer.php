<footer>
            <div class="footer-area">
                <p>Zoo Management System by Sliate students </p>
            </div>
        </footer>