<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['zmsaid']==0)) {
  header('location:logout.php');
} else {
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Zoo Management System || Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <style>
        .card {
            width: 90%;          /* or a fixed width like 300px */
            padding: 15px;       /* smaller inner space */
            font-size: 14px;     /* optional: smaller text */
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: none;
        }
        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 12px rgba(0, 0, 0, 0.2);
        }
        .card-header {
            font-size: 20px;
            padding: 20px;
            color: white;
            font-weight: bold;
            text-align: center;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }
        .card-body {
            padding: 10px;
            text-align: center;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
        }
        .card-body p {
            font-size: 22px;
            color: #333;
            font-weight: bold;
        }
        .row {
            display: flex;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .col-xl-4.card, .col-md-6 {
            max-width: 25%;
            margin-bottom: 21px;
            margin-left: 15px;   /* adds space to the left */
            margin-right: 15px;  /* adds space to the right */


        /* Unique Gradient Styles for each Card */
        .card:nth-child(1) .card-header {
            background: linear-gradient(135deg,rgb(0, 0, 0),rgb(161, 46, 193)); /* Orange-Red Gradient */
        }
        .card:nth-child(2) .card-header {
            background: linear-gradient(135deg,rgb(73, 54, 197), #483D8B); /* Blue-Purple Gradient */
        }
        .card:nth-child(3) .card-header {
            background: linear-gradient(135deg, #32CD32, #228B22); /* Green Gradient */
        }
        .card:nth-child(4) .card-header {
            background: linear-gradient(135deg, #00BFFF, #1E90FF); /* Blue Gradient */
        }
        .card:nth-child(5) .card-header {
            background: linear-gradient(135deg, #FFD700, #FFA500); /* Yellow-Orange Gradient */
        }
        .card:nth-child(6) .card-header {
            background: linear-gradient(135deg, #FF1493, #C71585); /* Pink Gradient */
        }
        .card:nth-child(7) .card-header {
            background: linear-gradient(135deg, #8A2BE2, #9400D3); /* Violet Gradient */
        }
        .card:nth-child(8) .card-header {
            background: linear-gradient(135deg, #FF6347, #FF4500); /* Tomato Gradient */
        }
        .card:nth-child(9) .card-header {
            background: linear-gradient(135deg, #F0E68C, #BDB76B); /* Khaki Gradient */
        }
        .card:nth-child(10) .card-header {
            background: linear-gradient(135deg, #ADFF2F, #7FFF00); /* Green Yellow Gradient */
        }
        .card:nth-child(11) .card-header {
            background: linear-gradient(135deg, #8B0000, #B22222); /* Dark Red Gradient */
        }
        .card:nth-child(12) .card-header {
            background: linear-gradient(135deg, #8B4513, #D2691E); /* Brown Gradient */
        }
    </style>
</head>

<body>
    <?php include_once('includes/sidebar.php'); ?>
    <div class="page-container">
        <div class="main-content">
            <?php include_once('includes/header.php'); ?>
            <?php include_once('includes/pagetitle.php'); ?>
            <div class="main-content-inner">
                <div class="row">
                    <?php
                    $queries = [
                        "select count(ID) as totalanimal from tblanimal" => "Total Animals",
                        "select sum(NoAdult) as totaladult from tblticindian" => "Total Normal Adult Visitor",
                        "select sum(NoChildren) as totalchild from tblticindian" => "Total Normal Children Visitor",
                        "select sum(NoAdult) as totaladult from tblticindian where date(PostingDate)=CURDATE()" => "Today Normal Adult Visitor",
                        "select sum(NoChildren) as totalchild from tblticindian where date(PostingDate)=CURDATE()" => "Today Normal Children Visitor",
                        "select sum(NoAdult) as totaladulty from tblticindian where date(PostingDate)=CURDATE()-1" => "Yesterday Normal Adult Visitor",
                        "select sum(NoChildren) as totalchildy from tblticindian where date(PostingDate)=CURDATE()-1" => "Yesterday Normal Child Visitor",
                        "select sum(NoAdult) as totaladult from tblticforeigner" => "Total Foreigner Adult Visitor",
                        "select sum(NoChildren) as totalchildy from tblticforeigner" => "Total Foreigner Child Visitor",
                        "select sum(NoAdult) as totaladult from tblticforeigner where date(PostingDate)=CURDATE()" => "Today Foreigner Adult Visitor",
                        "select sum(NoChildren) as totalchild from tblticforeigner where date(PostingDate)=CURDATE()" => "Today Foreigner Children Visitor",
                        "select sum(NoAdult) as totaladulty from tblticforeigner where date(PostingDate)=CURDATE()-1" => "Yesterday Foreigner Adult Visitor",
                        "select sum(NoChildren) as totalchildy from tblticforeigner where date(PostingDate)=CURDATE()-1" => "Yesterday Foreigner Child Visitor"
                    ];

                    $index = 0;
                    foreach ($queries as $sql => $title) {
                        $query = mysqli_query($con, $sql);
                        $result = mysqli_fetch_array($query);
                        $count = reset($result) ?: "0";
                        echo "<div class='col-xl-4 col-md-6'>
                                <div class='card'>
                                    <div class='card-header'>
                                        {$title}
                                    </div>
                                    <div class='card-body'>
                                        <p>{$count}</p>
                                    </div>
                                </div>
                              </div>";
                        $index++;
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php include_once('includes/footer.php'); ?>
    </div>

    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://cdn.zingchart.com/zingchart.min.js"></script>
    <script>
        zingchart.MODULESDIR = "https://cdn.zingchart.com/modules/";
        ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "ee6b7db5b51705a13dc2339db3edaf6d"];
    </script>
    <script src="assets/js/line-chart.js"></script>
    <script src="assets/js/bar-chart.js"></script>
    <script src="assets/js/pie-chart.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
</body>

</html>
<?php } ?>
